# Copyright 2023 The JAX Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""Contains bindings for Mosaic."""

from jax._src.tpu_custom_call import as_tpu_kernel as as_tpu_kernel
from jax._src.tpu_custom_call import lower_module_to_custom_call as lower_module_to_custom_call
from jax._src.tpu_custom_call import lowered_as_tpu_kernel as lowered_as_tpu_kernel
from jax._src.tpu_custom_call import MemorySpace as TpuMemorySpace  # noqa: F401
from jax._src.tpu_custom_call import OptLevel as OptLevel
from jax._src.tpu_custom_call import register_extra_dialect as _register_extra_dialect  # noqa: F401
from jax._src.tpu_custom_call import Tiling as Tiling
from jax._src.tpu_custom_call import TpuSideEffectType as TpuSideEffectType
